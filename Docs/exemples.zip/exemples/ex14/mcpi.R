## Estimation de Pi
## par simulation
## de Monte-Carlo

##---- nombre ----
n <- 100

##---- tirage ----
## graine du générateur de nombre (pseudo) aléatoire
set.seed(1823)
## tirage des coordonnées x et y dans le carré
## transformés de [0,1] à [-1,1]
x <- runif(n) * 2 - 1
y <- runif(n) * 2 - 1

##---- distance ----
## distance de (0,0)
z <- sqrt(x^2 + y^2)
## points inscrits dans le cercle
inscrits <- z <= 1
## estimateur de pi (équivalent de m/n*4)
pi_hat <- mean(inscrits)*4
# pi_hat

##---- plot1 ----
## points dans l'espace
# dev.off()
# graphe carré
par(pty="s")
# limites du graphe
lims <- c(-1,1)
# trace les points du disque
plot(x[inscrits], y[inscrits], pch = 20, col = rgb(0.8, 0.2, 0.1, 0.3),
     xlab = "", ylab = "", bty = "n",
     xlim = lims, ylim = lims,
     main = "Monte-Carlo Pi")
# trace les points hors du disque
points(x[!inscrits],y[!inscrits], pch = 20, col = rgb(0.1, 0.2, 0.8, 0.3))

##---- fin ----

