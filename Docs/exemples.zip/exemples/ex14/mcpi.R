##-------------------
## Estimation de Pi
## par simulation
## de Monte-Carlo
##-------------------

#  1+---------------+
#   |    XXXXXXX    |
#   |  XX       XX  |
#   | X           X |
#   |X             X|
#  0|X             X|
#   |X             X|
#   | X           X |
#   |  XX       XX  |
#   |    XXXXXXX    |
#   +---------------+
# -1        0       1

## graine du générateur de nombre (pseudo) aléatoire
set.seed(1823)
## nombre d'itérations
iter <- 1e3
## tirage des coordonnées x et y dans le carré (-1 à 1)
x <- runif(iter) * 2 - 1
y <- runif(iter) * 2 - 1
## distance de (0,0)
z <- sqrt(x^2 + y^2)
## points inscrits dans le cercle
m <- z <= 1
## estimateur de pi (équivalent de m/n*4)
pi_hat <- mean(m)*4
pi_hat

## plot 1: points dans l'espace
# dev.off()
# graphe carré
par(pty="s")
# limites du graphe
lims <- c(-1,1)
# trace les points du disque
plot(x[m], y[m], pch = 20, col = rgb(0.8, 0.2, 0.1, 0.3),
     xlab = "", ylab = "", bty = "n",
     xlim = lims, ylim = lims,
     main = "Monte-Carlo Pi")
# trace les points hors du disque
points(x[!m],y[!m], pch = 20, col = rgb(0.1, 0.2, 0.8, 0.3))

## Estimation à l'iteration i
iter_pi <- vapply(1:length(m), function(i){
  sum(m[1:i])/i*4
  }, numeric(1) )


## plot2: trace de l'estimateur
plot(x = 1:length(iter_pi), y = iter_pi,
     xlab = "iterations", ylab= "pi_hat",
     type = "l", col = 'blue',
     main = "Pi par itérations")
# reference de pi
abline(h = pi, col = "red", lty = 3)

### -----

## ou function
sim_pi <- function(n){
  est <- rep(0, n)
  compte <- 0
  for(i in 1:n){
    xy <- runif(2)
    z <- sqrt(xy[1]^2 + xy[2]^2)
    if (z <= 1) compte <- compte + 1
    est[i] <- compte / i * 4
  }
  est
}
k <- 1e5
pi_hats <- sim_pi(k)
tail(pi_hats, 1)
plot(x = 1:k, y = pi_hats, type = "l", col = "blue")
abline(h = pi, col = "red")
