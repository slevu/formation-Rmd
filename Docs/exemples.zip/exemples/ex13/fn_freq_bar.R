#' Ordered barplot with options
#' @param x named vector
#' @param lim limit values
#' @param h horizontal or not
#' @param fn_lbl optional abbreviation of labels
freq_bar <- function(x, lim = 0, h = TRUE,
                     fn_lbl = identity
){
  
  ## record and restore graphic par
  op <- par(no.readonly = TRUE)
  on.exit(par(op))
  
  a <- sort(x, decreasing = !h)
  
  {
    lbl <- fn_lbl(names(a[a > lim]))
    maxlbl <- max(sapply(lbl, nchar))
    # abbreviate(names(a))
    # substr(names(a), 1, 3)
    
    if(maxlbl > 5){ ##- make room for labels
      ## mar = c(bottom, left, top, right)
      ## default is c(5, 4, 4, 2) + 0.1.
      ifelse(h,
             par(mar = c(3, maxlbl / 2, 1, 2)),
             par(mar = c(maxlbl / 2, 3, 1, 2)) )
    }
    
    barplot(a[a > lim],
            names.arg = lbl,
            border = NA,
            horiz = h,
            las = ifelse(h, 1, 2))
    
  }
}