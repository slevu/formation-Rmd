# title: "Formation Rmd - Exemple 13"
# author: "S. Le Vu"
# date: "27/06/2019"

##---- import ----
general <- read.csv("europeennes19_general.csv",
               encoding = "UTF-8")
# head(general)

##---- dossier ----
## Creation dossier de résultats
DN <- "rapports_region"
dir.create(DN, showWarnings = FALSE)

##---- boucle ----
## - Dans cette boucle, un indice i de 1 à n libellés de région est utilisé
## de manière itérative pour générer des rapports
## - Le rapport est généré selon le document type .Rmd, en y injectant
##  les paramètres dans la variables 'params'
## - Le nom de fichier du rapport utilise aussi l'indice i
##
# n <- 2 # length(general)
genere_rapports <- function(n = 2, fmt = "html"){
  for ( i in 1:n ){ #
    rmarkdown::render(input = "ex13.Rmd",
                      output_format = paste0(fmt, "_document"),
                      params = list(region = general$Libelle_de_la_region[i],
                                    resultat = "p_Voix_sur_Exp",
                                    limite = 5),
                      encoding = "UTF-8",
                      output_file = paste0(DN, "/", "res_eur_",
                                           general$reg_ss_accent[i],
                                           ".", fmt))
  }
}

##---- run ----
## Execution de la fonction
genere_rapports()
# genere_rapports(n = 5, fmt = "pdf")
