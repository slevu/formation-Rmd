# title: "Formation Rmd - Exemple 13"
# author: "S. Le Vu"
# date: "27/06/2019"

##---- import ----
general <- read.csv("europeennes19_general.csv",
               fileEncoding = "UTF8")
# head(general)

## dossier
DN <- "rapports_region"
dir.create(DN, showWarnings = FALSE)

## loop
# n <- 2 # length(general)
genere_rapports <- function(n = 2, fmt = "html"){
  for ( i in 1:n ){ #
    rmarkdown::render(input = "ex13.Rmd",
                      output_format = paste0(fmt, "_document"),
                      params = list(region = general$Libelle_de_la_region[i],
                                    resultat = "p_Voix_sur_Exp",
                                    limite = 5),
                      output_file = paste0(DN, "/", "res_eur_",
                                           general$reg_ss_accent[i],
                                           ".", fmt))
  }
}
# genere_rapports(fmt = "pdf")
