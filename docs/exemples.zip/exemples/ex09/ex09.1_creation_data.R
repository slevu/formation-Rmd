## Script R

##---- data ----
n <- 200
k <- 5
df1 <- data.frame(x = rep(1:k, each = n/k),
                 y = {rnorm(n) + rep( cumsum(rpois(k,1)), each = n/k)})

