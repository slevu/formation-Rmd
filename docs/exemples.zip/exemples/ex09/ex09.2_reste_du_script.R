## Script R

##---- data ----
source("ex09.1_creation_data.R")

##---- export ----
write.csv(df1, file = "data.csv", row.names = FALSE)

##---- import ----
df1 <- read.csv("data.csv")

##---- plot ----
plot(jitter(df1$x), df1$y,
     xlab = "X", ylab = "Y",
     pch = 20,
     col = rgb(0.1, 0.2, 0.8, 0.3),
     bty = "n")
lines(lowess(df1, f = .1), col ="red")
