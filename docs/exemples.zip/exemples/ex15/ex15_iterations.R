## fonction pour générer les rapports
rapport_pi <- function(x){
  rmarkdown::render(input = "ex15.Rmd",
                    params = list(nb = x),
                    encoding = "UTF-8",
                    output_file = paste0("estimation_pi_", x, ".html")
  )
}

## génère deux rapports
rapport_pi(100)
rapport_pi(1000)
